// import index from './index_redux';
// import index from './index_mobx';
// import userMobx from './user-mobx';
import userRedux from './user-redux';

export default userRedux;
