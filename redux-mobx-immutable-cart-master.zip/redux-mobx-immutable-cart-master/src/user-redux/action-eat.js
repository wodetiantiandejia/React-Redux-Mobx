export const EAT_APPLE = 'EAT_APPLE';
export const eatApple = appleId => ({
  type: 'EAT_APPLE',
  appleId
});
